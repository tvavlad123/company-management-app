import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.css']
})
export class CalendarComponent implements OnInit {

  year: number;
  month: string;
  monthnr: number;
  daysInM: number;
  currentDay: number=1;
  items: any[];
  dayInW:number;


  constructor() { }

  ngOnInit() {
    this.getCurrentDate();
    this.daysInM=this.daysInMonth(this.monthnr,this.year);
    this.ale();
    this.dayInW=this.dayInWeek();
  }

  ale(): void{
      this.items = [{day:"Mo"},{day:"Tu"},{day:"We"},{day:"Th"},{day:"Fr"}];
      this.items = this.items.concat(this.items).concat(this.items).concat(this.items).concat(this.items);  
  }

  getCurrentDate(): void{
    this.year=new Date().getFullYear() ;
    var monthNames = ["January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"];
    this.monthnr=new Date().getMonth();
    this.month=monthNames[this.monthnr];
  }

  nextMonth(): void{
    var monthNames = ["January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"];
    if (this.monthnr==11){
      this.year++;
      this.monthnr=0;
      this.month=monthNames[this.monthnr];
    }
    else{
      this.monthnr++;
      this.month=monthNames[this.monthnr];
    }
    this.dayInW=this.dayInWeek();
  }

  prevMonth(): void{
    var monthNames = ["January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"];
    if (this.monthnr==0){
      this.year--;
      this.monthnr=11;
      this.month=monthNames[this.monthnr];
    }
    else{
      this.monthnr--;
      this.month=monthNames[this.monthnr];
    }
    this.dayInW=this.dayInWeek();
  }


 daysInMonth(month,year): number {
      return new Date(year, month, 0).getDate();
  }

  dayInWeek(): number{
    var date= new Date(this.year, this.monthnr, 1);
   
    var dayOfWeek=date.getDay();
    console.log(dayOfWeek)
    return dayOfWeek;
  }

}
